<?php get_header(); ?><!-- created on page 103 -->




					<section id="content" class="widecol alignleft">




					
						<div id="posts">




					
							<h2 class="osc-cond txttranup">You are viewing the "Uncategorized" Archives</h2><!-- modified on page 168 -->




							<!-- START The Loop found on page 107 -->
							<article class="halfcol clear alignleft"><!-- Post Class page 248 -->
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" /><!-- modified on page 108 and page 195-->
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							
							
							<!-- END The Loop found on page 107 -->
							<div class="clear"></div>
						</div><!-- posts -->
						
						
						
						
						<!-- START Call to pagination function page 228 -->
						<nav id="pagination" class="clear">
							<ul class='page-numbers'>
								<li><span class='page-numbers current'>1</span></li>
								<li><a class='page-numbers' href='page/2/'>2</a></li>
								<li><a class='page-numbers' href='page/3/'>3</a></li>
								<li><a class="next page-numbers" href="page/2/">&gt;</a></li>
							</ul>
							<div class="clear"></div>
						</nav><!-- .pagination -->
						<!-- END Call to pagination function page 228 -->
						
						
						
						
					</section>
					
					
					<!-- Start get_sidebar() -->	
					<?php get_sidebar(); ?> <!-- created on page 126 -->
					<!-- End get_sidebar() -->	
						
						
						
<?php get_footer(); ?><!-- created on page 113 -->