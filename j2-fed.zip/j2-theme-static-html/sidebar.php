					
					<aside class="narcolrt alignleft">
						
						<!-- This section is optional and for a newsletter signup. Remember you can custom forms and other elements directly into your theme -->
						<div class="important clearfix">
							<h3 class="osc text-shad txttranup">Subscribe to J2 Design's Newsletter</h3>
								<form id="newsletter-signup" action="#" method="post">
									<input id="newsletter-signup" name="newsletter-signup" type="text" value="email" class="alignleft italic">
									<input id="submit" name="submit" type="submit" value="submit" class="txttranup alignleft osc-cond text-shad">
								</form><!-- newsletter signup -->
																 
							<nav class="alignright social">
								<ul>
									<li class="alignleft nobull"><a href="http://twitter.com/professor" target="_blank"><img src="images/social/twitter-lg.png" alt="Twitter Icon" title="J2 Design on Twitter"></a></li>
									<li class="alignleft nobull"><a href="https://www.facebook.com/wordpressandweb" target="_blank"><img src="images/social/facebook-lg.png" alt="Facebook Icon" title="J2 Design on Facebook"></a></li>					
									<li class="alignleft nobull"><a href="feed/" target="_blank"><img src="images/social/rss-lg.png" alt="J2 Design RSS Icon" title="Subscribe to J2 Design"></a></li>
								</ul>
							</nav><!-- .social -->
							
						</div><!-- .important -->
						<!-- END: This section is optional and for a newsletter signup. Remember you can custom forms and other elements directly into your theme -->
						
						<!-- Start dyanamic_sidebar() page 127 -->
						<div class="widget">
							<h3 class="widgettitle">Recent Posts</h3>
							<ul>
								<li><a href="uncategorized/about-jesse-friedman/" title="About Jesse Friedman">About Jesse Friedman</a></li>
								<li><a href="uncategorized/this-is-a-test/" title="This is a test">This is a test</a></li>
								<li><a href="uncategorized/welcome-to-wordpress/" title="Welcome to WordPress.">Welcome to WordPress.</a></li>
								<li><a href="uncategorized/hello-world/" title="Legal Advice">Legal Advice</a></li>
								<li><a href="uncategorized/about-jeff-golenski/" title="About Jeff Golenski">About Jeff Golenski</a></li>
							</ul>
						</div><!-- .widget -->
						<!-- END dyanamic_sidebar() page 127 -->
						
						
					</aside><!-- aside (sidebar) -->