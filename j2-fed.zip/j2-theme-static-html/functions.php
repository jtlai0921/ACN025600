<?php

/* Register Menus on page 90 */




/* Register Sidebars on page 119 */
/* Register Sidebar on page 181 */



/* Post Type Support for Tagline found on page 158 */




/* Register Post Thumbnails on page 192 */




/* Custom Pagination function page 227 */




/* Custom Header and Background support page 249 */