<?php get_header(); ?><!-- created on page 103 -->




					<section id="content" class="widecol alignleft">
					
					
						<!-- START WP_Query() Slider -->
						<div class="slider-wrapper theme-default">
							<div id="slider" class="nivoSlider">
								<a href="" ><!-- get Custom Field page 205 --><img src="imgs/lg-slider.jpg" data-thumb="imgs/lg-slider.jpg" alt="" title=""  ><!-- modified on page 195 --></a>
							</div><!-- slider -->
						</div><!-- slider-wrapper -->
						<!-- END WP_Query() Slider -->
						
						
						<div id="posts">
						
							<h2 class="osc-cond txttranup">Uncategorized</h2><!-- modified on page 106 -->
							
							<!-- START The Loop found on page 107 -->
							<article class="post halfcol clear alignleft"><!-- Post Class page 248 --><!-- Loop structure built on pages 108-110 -->
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" /><!-- modified on page 108 and page 195-->
								<h3><a href="" title="">About Jesse Friedman</a></h3><!-- modified on page 108-109 -->
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p><!-- modified on page 109 -->
							</article>
							<article class="post halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcol clear alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<article class="post halfcolrt alignleft">
								<img width="260" height="175" src="imgs/lg-thumb.png" class="attachment-post-thumb wp-post-image" alt="" title="example" />
								<h3><a href="" title="">About Jesse Friedman</a></h3>
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="" title="">4 comments</a></p>
							</article>
							<!-- END The Loop found on page 107 -->
						
						
						
						<div class="clear"></div>
						</div><!-- posts -->
						
						
						
						
						<!-- START Call to pagination function page 228 -->
						<nav id="pagination" class="clear">
							<ul class='page-numbers'>
								<li><span class='page-numbers current'>1</span></li>
								<li><a class='page-numbers' href='page/2/'>2</a></li>
								<li><a class='page-numbers' href='page/3/'>3</a></li>
								<li><a class="next page-numbers" href="page/2/">&gt;</a></li>
							</ul>
							<div class="clear"></div>
						</nav><!-- .pagination -->
						<!-- END Call to pagination function page 228 -->						
						
						
						
					</section>
						
						
						
					<!-- Start get_sidebar() -->	
					<?php get_sidebar(); ?> <!-- created on page 126 -->
					<!-- End get_sidebar() -->	
						
						
						
<?php get_footer(); ?><!-- created on page 113 -->