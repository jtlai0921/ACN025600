<?php get_header(); ?><!-- created on page 103 -->




					<section id="content" class="widecol alignleft">
					
					
					
						<!-- START The Loop page 132 -->
						<div>
							<img width="530" height="95" src="imgs/page-featured-image.jpg" class="attachment-page-featured-image wp-post-image" alt="" title="example" /><!-- modified on page 133 and page 195 -->
						</div><!-- featured image -->
						
						
						<article class="post"><!-- Post Class page 248 -->
						
						
							<header>
								<h1 class="text-shad-lt">About Jesse Friedman</h1><!-- modified page 133 -->
								<p class="meta">Posted <time datetime="2012-05-26" pubdate="pubdate">May 5</time> &#149; <a href="uncategorized/about-jesse-friedman/#comments" title="About Jesse Friedman Comments">1 comment</a></p><!-- modified page 133 -->
							</header>	
						
						
							<div class="content"><!-- modified page 135 -->
								<div id="attachment_57" class="wp-caption alignleft" >
									<a href="imgs/photo-220x180.jpg"><img src="imgs/photo-220x180.jpg" alt="" title="example" width="220" height="180" class="size-medium wp-image-57" /></a>
									<p class="wp-caption-text">This is my caption, what do you think?</p>
								</div>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum vel, pharetra vel lectus. Fusce non facilisis neque. Integer nec orci id purus euismod rutrum sed a dui. Donec vel consequat nisi. Vestibulum scelerisque dui placerat metus commodo suscipit. Aenean pulvinar, turpis vitae scelerisque hendrerit, leo nulla bibendum nunc, nec aliquam felis ipsum vitae diam. Donec pharetra, turpis vel suscipit laoreet, arcu nisl varius lacus, ut porta massa sapien tempor ipsum. Morbi rhoncus laoreet augue, id adipiscing lacus vestibulum sagittis. Proin laoreet, mi a dictum tincidunt, lectus purus molestie odio, ac accumsan magna libero elementum ante. Quisque commodo pulvinar volutpat.</p>
								
							</div><!-- content -->
						
						
							<footer>
								<div class="tax clearfix">
									<div class="alignleft">
										<p>Filed Under: <a href="category/uncategorized/" title="View all posts in Uncategorized" rel="category tag">Uncategorized</a></p><!-- modified page 137 -->
									</div>
								</div>
								<div class="alignright">
									<p>Tags: <a href="http://localhost/j2-theme/tag/chattels/" rel="tag">chattels</a>, <a href="http://localhost/j2-theme/tag/privation/" rel="tag">privation</a></p>
								</div><!-- modified page 137 -->
							</footer>
							
							
							<nav id="pagi" class="clearfix">
								<ul>
									<li><a href="uncategorized/this-is-a-test/" rel="prev">&lt; Previous Post</a></li><!-- modified on page 141 -->
								</ul>
							</nav><!-- .pagination -->
							
							
							
						</article>
						
					
					
						<!-- START Author section pages 139-141 -->
						<div class="author clearfix">
							<h3>Written by: <a href="author/jfriedman/" title="Posts by Jesse Friedman" rel="author">Jesse Friedman</a></h3>
							<img alt='Avatar of Jesse Friedman' src='http://0.gravatar.com/avatar/0934fa64cc323b6a2e10dc37fc33fa64?s=150&amp;d=Mystery+Man&amp;r=G' class='avatar avatar-150 photo' height='150' width='150' />																	
							<p>Cras faucibus, diam id eleifend interdum, nibh ante fermentum lorem, ut varius metus leo vel quam. Curabitur tempor posuere laoreet. Nunc arcu magna, lobortis id tempus non, porttitor vel orci. Sed nec congue eros. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis sit amet urna eu augue eleifend scelerisque. Nam tincidunt arcu sed tellus fringilla malesuada. Sed quam lacus, volutpat vel euismod eu, dapibus quis magna. Donec malesuada semper varius. Morbi euismod tristique molestie. Nam pharetra arcu id urna varius id congue dui ullamcorper. Curabitur magna mauris, facilisis non sodales ornare, accumsan sagittis velit. Integer lacinia, turpis egestas gravida ornare, urna eros semper tellus, in cursus magna nunc et erat. Donec sit amet ipsum urna. Nulla massa lacus, tristique nec faucibus et, dictum ac libero.</p>
							<a href="http://jesserfriedman.com" title="Jesse's Website" target="_blank">http://jes.se.com</a> 
						</div><!-- author -->
						<!-- END Author section pages 139-141 -->
					
					
						<!-- START Author section pages 142 -->
						<div class="comments">
							<h3 id="comments">4 Responses to &#8220;About Jesse Friedman&#8221;</h3>
							<ol class="commentlist">
								<li class="comment even thread-even depth-1 parent" id="comment-37">
									<div id="div-comment-37" class="comment-body">
										<div class="comment-author vcard">
											<img alt='' src='http://1.gravatar.com/avatar/bb9b1e9ed6ac9b3d73e35aa2a1eca8b7?s=100&amp;d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D100&amp;r=G' class='avatar avatar-100 photo' height='100' width='100' />		
											<cite class="fn"><a href='http://jes.se.com' rel='external nofollow' class='url'>Jesse Friedman</a></cite> 	<span class="says">says:</span>		
										</div>
										<div class="comment-meta commentmetadata"><a href="uncategorized/about-jesse-friedman/#comment-37">August 14, 2012 at 3:05 pm</a>&nbsp;&nbsp;<a class="comment-edit-link" href="wp-admin/comment.php?action=editcomment&amp;c=37" title="Edit comment">(Edit)</a>		
										</div>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer metus lacus, ultrices vitae bibendum sed, rhoncus eu tellus. Fusce tincidunt, purus sed euismod gravida, est nibh lobortis urna, eget convallis nibh velit a lectus. Duis sed ligula orci, vel ultricies lorem. Vivamus eget leo sed.</p>
					]					<div class="reply">
											<a class='comment-reply-link' href='/j2-theme/uncategorized/about-jesse-friedman/?replytocom=37#respond' onclick='return addComment.moveForm("div-comment-37", "37", "respond", "56")'>Reply</a>	
										</div>
									</div>
								</li>
							</ol>
							<div id="respond">
								<h3>Leave a Reply</h3>
								<div id="cancel-comment-reply">
									<small><a rel="nofollow" id="cancel-comment-reply-link" href="/j2-theme/uncategorized/about-jesse-friedman/#respond" style="display:none;">Click here to cancel reply.</a></small>
								</div>
								<form action="wp-comments-post.php" method="post" id="commentform">
									<p><label for="author"><small>Name* (required)</small></label><input type="text" name="author" id="author" value="" size="22" tabindex="1" aria-required='true' /></p>
									<p><label for="email"><small>Email (will not be published)* (required)</small></label>
<input type="text" name="email" id="email" value="" size="22" tabindex="2" aria-required='true' /></p>
									<p><label for="url"><small>Website</small></label><input type="text" name="url" id="url" value="http://jes.se.com" size="22" tabindex="3" /></p>
									<p><label for="comment"><small>Your Comment*</small></label><textarea name="comment" id="comment" cols="58" rows="10" tabindex="4"></textarea></p>
									<p><input name="submit" type="submit" id="submit" tabindex="5" value="Post Comment" /></p>
								</form>
							</div>
						</div><!-- comments-->
						<!-- END Author section pages 142 -->
						
						
						
						<!-- END The Loop page 132 -->
						
						
						
						
					</section>
					
					
					<!-- Start get_sidebar() -->	
					<?php get_sidebar(); ?> <!-- created on page 126 -->
					<!-- End get_sidebar() -->	
						
						
						
<?php get_footer(); ?><!-- created on page 113 -->