</div><!-- widthfull mar0auto -->
			</div><!-- #container -->
						
						
						
						
			<section class="upper-footer clearfix">
				<div class="width100pad widthfull mar0auto">
					<div class="widget thirdcol alignleft">
					<!-- START dyanamic_sidebar() page 127 -->
						<h3 class="widgettitle">About Me</h3>
						<div class="textwidget">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer metus lacus, ultrices vitae bibendum sed, rhoncus eu tellus. Fusce tincidunt, purus sed euismod gravida, est nibh lobortis urna, eget convallis nibh velit a lectus. Duis sed ligula orci, vel ultricies lorem. Vivamus eget leo sed.</p>
						</div>
					</div><!-- class: widget -->
					<div class="widget thirdcol alignleft">
						<h3 class="widgettitle">Tags</h3>
						<div class="tagcloud">
							<a href='tag/chattels/' class='tag-link-58' title='2 topics' style='font-size: 11.4054054054pt;'>chattels</a>
							<a href='tag/cienaga/' class='tag-link-59' title='1 topic' style='font-size: 8pt;'>cienaga</a>
							<a href='tag/claycold/' class='tag-link-60' title='1 topic' style='font-size: 8pt;'>claycold</a>
							<a href='tag/crushing/' class='tag-link-61' title='1 topic' style='font-size: 8pt;'>crushing</a>
							<a href='tag/dinarchy/' class='tag-link-63' title='1 topic' style='font-size: 8pt;'>dinarchy</a>
							<a href='tag/doolie/' class='tag-link-64' title='1 topic' style='font-size: 8pt;'>doolie</a>
							<a href='tag/energumen/' class='tag-link-65' title='1 topic' style='font-size: 8pt;'>energumen</a>
							<a href='tag/ephialtes/' class='tag-link-66' title='1 topic' style='font-size: 8pt;'>ephialtes</a>
							<a href='tag/eudiometer/' class='tag-link-67' title='1 topic' style='font-size: 8pt;'>eudiometer</a>
							<a href='tag/figuriste/' class='tag-link-68' title='1 topic' style='font-size: 8pt;'>figuriste</a>
							<a href='tag/habergeon/' class='tag-link-71' title='1 topic' style='font-size: 8pt;'>habergeon</a>
							<a href='tag/hapless/' class='tag-link-72' title='1 topic' style='font-size: 8pt;'>hapless</a>
							<a href='tag/hartshorn/' class='tag-link-73' title='1 topic' style='font-size: 8pt;'>hartshorn</a>
							<a href='tag/hostility-impregnability/' class='tag-link-74' title='1 topic' style='font-size: 8pt;'>hostility impregnability</a>
							<a href='tag/impropriation/' class='tag-link-75' title='1 topic' style='font-size: 8pt;'>impropriation</a>
							<a href='tag/knave/' class='tag-link-77' title='1 topic' style='font-size: 8pt;'>knave</a>
							<a href='tag/misinformed/' class='tag-link-78' title='1 topic' style='font-size: 8pt;'>misinformed</a>
							<a href='tag/moil/' class='tag-link-79' title='1 topic' style='font-size: 8pt;'>moil</a>
							<a href='tag/mornful/' class='tag-link-80' title='1 topic' style='font-size: 8pt;'>mornful</a>
							<a href='tag/outlaw/' class='tag-link-81' title='1 topic' style='font-size: 8pt;'>outlaw</a>
							<a href='tag/pamphjlet/' class='tag-link-82' title='1 topic' style='font-size: 8pt;'>pamphjlet</a>
							<a href='tag/pneumatics/' class='tag-link-83' title='1 topic' style='font-size: 8pt;'>pneumatics</a>
							<a href='tag/portly-portreeve/' class='tag-link-84' title='1 topic' style='font-size: 8pt;'>portly portreeve</a>
							<a href='tag/post-formats/' class='tag-link-85' title='10 topics' style='font-size: 22pt;'>Post Formats</a>
							<a href='tag/posts/' class='tag-link-6' title='1 topic' style='font-size: 8pt;'>posts</a>
							<a href='tag/precipitancy/' class='tag-link-86' title='1 topic' style='font-size: 8pt;'>precipitancy</a>
							<a href='tag/privation/' class='tag-link-87' title='2 topics' style='font-size: 11.4054054054pt;'>privation</a>
							<a href='tag/programme/' class='tag-link-88' title='1 topic' style='font-size: 8pt;'>programme</a>
							<a href='tag/psychological/' class='tag-link-89' title='1 topic' style='font-size: 8pt;'>psychological</a>
							<a href='tag/puncher/' class='tag-link-90' title='1 topic' style='font-size: 8pt;'>puncher</a>
							<a href='tag/ramose/' class='tag-link-91' title='1 topic' style='font-size: 8pt;'>ramose</a>
							<a href='tag/renegade/' class='tag-link-92' title='1 topic' style='font-size: 8pt;'>renegade</a>
							<a href='tag/retrocede/' class='tag-link-93' title='1 topic' style='font-size: 8pt;'>retrocede</a>
							<a href='tag/stagnation-unhorsed/' class='tag-link-94' title='1 topic' style='font-size: 8pt;'>stagnation unhorsed</a>
							<a href='tag/tag1/' class='tag-link-98' title='1 topic' style='font-size: 8pt;'>tag1</a>
							<a href='tag/tag2/' class='tag-link-99' title='1 topic' style='font-size: 8pt;'>tag2</a>
							<a href='tag/tag3/' class='tag-link-100' title='1 topic' style='font-size: 8pt;'>tag3</a>
							<a href='tag/test/' class='tag-link-7' title='1 topic' style='font-size: 8pt;'>test</a>
							<a href='tag/thunderheaded/' class='tag-link-103' title='1 topic' style='font-size: 8pt;'>thunderheaded</a>
							<a href='tag/unculpable/' class='tag-link-104' title='1 topic' style='font-size: 8pt;'>unculpable</a>
							<a href='tag/withered-brandnew/' class='tag-link-105' title='1 topic' style='font-size: 8pt;'>withered brandnew</a>
							<a href='tag/wordpress/' class='tag-link-5' title='1 topic' style='font-size: 8pt;'>wordpress</a>
							<a href='tag/xanthopsia/' class='tag-link-106' title='1 topic' style='font-size: 8pt;'>xanthopsia</a>
						</div>
					</div><!-- class: widget -->		
					<div class="widget thirdcol alignleft">
						<h3 class="widgettitle">Recent Posts</h3>
						<ul>
							<li><a href="uncategorized/about-jesse-friedman/" title="About Jesse Friedman">About Jesse Friedman</a></li>
							<li><a href="uncategorized/this-is-a-test/" title="This is a test">This is a test</a></li>
							<li><a href="uncategorized/welcome-to-wordpress/" title="Welcome to WordPress.">Welcome to WordPress.</a></li>
							<li><a href="uncategorized/hello-world/" title="Legal Advice">Legal Advice</a></li>
							<li><a href="uncategorized/about-jeff-golenski/" title="About Jeff Golenski">About Jeff Golenski</a></li>
						</ul>
					</div><!-- class: widget -->
					<!-- END dyanamic_sidebar() page 127 -->
					
					
					
				</div><!-- width100pad -->
			</section><!-- .upper-footer -->
						
						
						
						
			<footer class="main">
				<div class="width100pad clearfix widthfull mar0auto">
					<div class="widecol alignleft">
						
						
						
						
						<!-- START wp_nav_menu() function found on page 97 (classes may be different due to updates) -->
						<nav id="footer-main" class="menu-main-container">
							<ul id="footer-nav" class="menu">
								<li><a href="">Home</a></li>
								<li><a href="">About</a></li>
								<li><a href="">News</a></li>
								<li><a href="">Contact</a></li>
							</ul>
						</nav>
						<!-- END wp_nav_menu() function found on page 97 -->
						
						
						
						
						<!-- START dyanamic_sidebar() page 127 -->
						<div class="widget clear">
							<p>Business Name<br>132 Theme Road, Themeville, USA<br>Phone: 555-555-5555<br>Fax: 444-444-4444<br><a href="mailto:info@wdgwp.com" title="Email Jesse Friedman">info@wdgwp.com</a></p>
						</div><!-- .widget -->	
						<!-- END dyanamic_sidebar() page 127 -->
					</div><!-- widecol -->	
						
						
						
						
					<div class="narcolrt alignright">				 
						<nav class="alignright social">
							<ul>
								<li class="alignleft nobull"><a href="http://twitter.com/professor" target="_blank"><img src="images/social/twitter-lg.png" alt="Twitter Icon" title="J2 Design on Twitter"></a></li>
								<li class="alignleft nobull"><a href="https://www.facebook.com/wordpressandweb" target="_blank"><img src="images/social/facebook-lg.png" alt="Facebook Icon" title="J2 Design on Facebook"></a></li>					
								<li class="alignleft nobull"><a href="feed/" target="_blank"><img src="images/social/rss-lg.png" alt="J2 Design RSS Icon" title="Subscribe to J2 Design"></a></li>
							</ul>
						</nav><!-- .social -->
						
						
						
						
						<form class="alignright">
							<input id="s" name="s" type="text" value="search" class="osc italic txttranup">
							<input id="submit" name="submit" type="submit" value="" class="alignleft">
						</form><!-- form (search box) -->
						
						
						
						<!-- START dyanamic_sidebar() page 127 -->
						<div class="clear vcard copyright alignright">
								<p>Copyright 2012 J2 Theme, All Rights Reserved</p>
						</div><!-- .vcard .copyright -->
						<!--END dyanamic_sidebar() page 127 -->
						
						
						
					</div>
				</div><!-- width100pad -->
			</footer>
		</div><!-- width100pad -->
		<!-- wp_footer() page 84 -->
	</body>
</html>