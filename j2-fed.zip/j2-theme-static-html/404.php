<?php get_header(); ?><!-- created on page 103 -->




					<section id="content" class="width100 alignleft">	




						
						<h1 class="error">Whoops, 404!</h2>
						<h2 class="tagline">We're sorry, we can't find what you're looking for. It's probably our fault. Please use the navigation above or below and try again!</h2><!-- discussed on page 179 -->
						
						
						
						
						<form role="search" method="get" id="searchform" action="" >
							<div>	
								<label class="screen-reader-text" for="s">Search for:</label>
								<input type="text" value="" name="s" id="s" />
								<input type="submit" id="searchsubmit" value="Search" />
							</div>
						</form>	<!-- modified on page 179 -->
						
						
						
										
						<div class="widget">
							<h3 class="widgettitle">Recent Posts</h3>
							<ul>
								<li><a href="uncategorized/about-jesse-friedman/" title="About Jesse Friedman">About Jesse Friedman</a></li>
								<li><a href="uncategorized/this-is-a-test/" title="This is a test">This is a test</a></li>
								<li><a href="uncategorized/welcome-to-wordpress/" title="Welcome to WordPress.">Welcome to WordPress.</a></li>
								<li><a href="uncategorized/hello-world/" title="Legal Advice">Legal Advice</a></li>
								<li><a href="uncategorized/about-jeff-golenski/" title="About Jeff Golenski">About Jeff Golenski</a></li>
							</ul>
						</div><!-- modified on page 182 -->
						
						
						
						
						
					</section>
					
<?php include 'footer.php';
/* get_footer(); */?>