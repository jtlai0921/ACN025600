<?php get_header(); ?><!-- created on page 103 -->




					<section id="content" class="widecol alignleft">




					
						<form role="search" method="get" id="searchform" action="" >
							<div>
								<label class="screen-reader-text" for="s">Search for:</label>
								<input type="text" value="a" name="s" id="s" />
								<input type="submit" id="searchsubmit" value="Search" />
							</div>
						</form><!-- modified on page 174 -->




					
						
						<h2 class="osc-cond txttranup">You are searching for "a"</h2><!-- modified on page 173 -->
						<div id="posts">
						
						
						<!-- START The Loop found on page 175 -->
							<article class="post"><!-- Post Class page 248 -->
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							<article class="post">
								<header>
									<h3><a href="" title="">About Jesse Friedman</a></h3>
									<p class="meta">Posted <time datetime="2008-09-05" pubdate="pubdate">Sep 9</time> • <a href="readability-test/#comments" title="Readability Test Comments">0 comments</a></p>								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent elit sem, ultrices sit amet pharetra eu, fringilla nec ligula. Curabitur vel odio lectus, vitae pellentesque felis. Suspendisse nec dolor id nunc rutrum faucibus sit amet id metus. Quisque mollis vestibulum lorem et ultrices. Sed lacinia accumsan lectus bibendum dapibus. Sed neque metus, vehicula vel elementum [...]</p>
							</article>
							
							

							<!-- END The Loop found on page 107 -->
							<div class="clear"></div>
						</div><!-- posts -->
						
						
						
						
						<nav id="pagination" class="clear">
							<ul class='page-numbers'>
								<li><span class='page-numbers current'>1</span></li>
								<li><a class='page-numbers' href='page/2/'>2</a></li>
								<li><a class='page-numbers' href='page/3/'>3</a></li>
								<li><a class="next page-numbers" href="page/2/">&gt;</a></li>
							</ul>
							<div class="clear"></div>
						</nav><!-- .pagination -->
						
						
						
						
						
					</section>
					
					
					<!-- Start get_sidebar() -->	
					<?php get_sidebar(); ?> <!-- created on page 126 -->
					<!-- End get_sidebar() -->	
						
						
						
<?php get_footer(); ?><!-- created on page 113 -->